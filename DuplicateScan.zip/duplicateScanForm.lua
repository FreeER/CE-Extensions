--##### Save Dissect Code Lua Script for Cheat Engine
--##### Author: FreeER (based on DB code snippet)
--##### Github: https://github.com/FreeER
--##### Website: https://www.facebook.com/groups/CheatTheGame
--##### YouTube: https://www.youtube.com/channel/UCLy60mbqc3rSvh42jkpCDxw

-- START OF USER CONFIG --
local useGroupMenu = true
-- END OF CONFIG --

-- START OF EXT TEMPLATE CONFIG --
local extGroupMenuCaption = 'F&reeER\'s Extensions'
local extItemCaption = 'Duplicate Scan'
local requiredVersion = 6.4 -- requirement for inputQuery
-- START OF EXT TEMPLATE CONFIG --

if getCEVersion() < requiredVersion then
    error(("%s requires CE >= %d, update CE!"):format(extItemCaption, requiredVersion))
end

-- menu code --
local mf = getMainForm()
local mm = mf.Menu
local extMenu = nil

if useGroupMenu then
  -- look for existing group menu
  for i=0,mm.Items.Count-1 do
      if mm.Items.Item[i].Caption == extGroupMenuCaption then
          extMenu = mm.Items.Item[i]
          break
      end
  end
  if not extMenu then -- not found so create it
      extMenu = createMenuItem(mm)
      extMenu.Caption = extGroupMenuCaption
      mm.Items.add(extMenu)
  end
else
  extMenu = mm.Items
end

local extMenuItem = createMenuItem(extMenu)
extMenuItem.Caption = extItemCaption
extMenu.add(extMenuItem)
-- menu code --
extMenuItem.OnClick = function() DupScanForm.show() end
function file_exists(name)
   local f=io.open(name,"r")
   if f~=nil then io.close(f) return true else return false end
end
local formPath = getCheatEngineDir()..[[\autorun\forms\DupScanForm.frm]]
if not file_exists(formPath) then
  extMenuItem.destroy()
  print("frm for duplicate scan from was not found at '" .. formPath .. "'")
  return
end
local DupScanForm = createFormFromFile(formPath)
local state = 0
local scan = nil
local path = nil
local dupscan = nil
local duppath = nil

function DupScanFormCloseClick()
  DupScanForm.hide()
end

function duplicateScanForm_CEButton1Click(sender)
  if state == 0 then
    scan = getCurrentMemscan()
    path = scan.scanResultFolder
    DupScanForm.CELabel1.Caption = "Switch to scan tab to overwrite"
    DupScanForm.CEButton1.Caption = "Next"
    state = 1
  elseif state == 1 then
    dupscan = getCurrentMemscan()
    duppath = dupscan.scanResultFolder
    state = 2
    DupScanForm.CELabel1.Caption = "Switch to another tab (to let CE Unlock files)"
    DupScanForm.CEButton1.Caption = "Finish"
  elseif state == 2 then
    --print(path)
    --print(duppath)

    -- replace dupscan data (delete and copy)
    -- not sure why shellExecute did not work...
    os.execute("del \"" .. duppath .. "*\" /Q")
    os.execute("copy \"" .. path .. "*\" \"" .. duppath .. "\"")

    if DupScanForm.CECheckbox1.Checked then
      scan.saveCurrentResults(DupScanForm.CEEdit1.Text)
    end

    -- reset state
    state = 0
    DupScanForm.CELabel1.Caption = "Select the scan tab to duplicate and enter name below"
    DupScanForm.CEButton1.Caption = "Start"
  else
    print("Unknown state " .. state)
    state = 0
  end
end
